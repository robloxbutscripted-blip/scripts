﻿loadstring(game:HttpGet("https://pastebin.com/raw/LREcsnE5"))()
