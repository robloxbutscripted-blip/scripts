loadstring(game:HttpGet('https://raw.smokingscripts.org/vertex.lua'))()
